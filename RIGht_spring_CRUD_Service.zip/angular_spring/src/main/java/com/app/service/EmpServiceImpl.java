 package com.app.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.app.dao.EmpRepo;
import com.app.exception.ResourceNotFoundException;
import com.app.model.Emp;

@Service
public class EmpServiceImpl implements EmpService {

	
	@Autowired
	private EmpRepo employeeRepository;
	
	//get
	@Override
	public List<Emp> getmyEmp() {

		List<Emp> getEmp = employeeRepository.findAll();
		
		return getEmp;
	}

	//post
	@Override
	public Emp saveEmp(Emp employee){
		return employeeRepository.save(employee);
		
	}
	
	//put
	@Override
	public Emp updateEmp( int id, Emp employeeupdate){
		Emp employee =employeeRepository.findById(id)
				.orElseThrow(()->new ResourceNotFoundException("employee not exists with id"));
		employee.setName(employeeupdate.getName());
		employee.setAddress(employeeupdate.getAddress());
		employee.setGender(employeeupdate.getGender());
		employee.setDate(employeeupdate.getDate());
		employee.setHobbie(employeeupdate.getHobbie());
		employee.setCars(employeeupdate.getCars());
		System.out.println(employee);
		
		  employeeRepository.save(employee);
		return employee;

}

	@Override
	public void deleteEmp(int id) {
		// TODO Auto-generated method stub
		Emp employee =employeeRepository.findById(id)
				.orElseThrow(()->new ResourceNotFoundException("employee not exists with id"));
		
		employeeRepository.delete(employee);
			
	}
	
	
	

}
