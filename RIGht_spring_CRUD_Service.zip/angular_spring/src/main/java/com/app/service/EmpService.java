package com.app.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.app.model.Emp;

public interface EmpService {
	
	
	public List<Emp> getmyEmp(); 
	
	public Emp saveEmp(Emp employee);
	
	public Emp updateEmp( int id,Emp employeeupdate);

	public void deleteEmp( int id);
}
 